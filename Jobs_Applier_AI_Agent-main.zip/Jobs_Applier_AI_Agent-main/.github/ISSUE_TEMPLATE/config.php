blank_issues_enabled: true
contact_links:
  - name: Questions
    url: t.me/AIhawkCommunity
    about: You can join the discussions on Telegram.
  - name: New issue
    url: >-
      https://github.com/feder-cr/Auto_Jobs_Applier_AIHawk/blob/v3/.github/CONTRIBUTING.md
    about: "Before opening a new issue, please make sure to read CONTRIBUTING.md"
